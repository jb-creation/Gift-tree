import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter_image_compress/flutter_image_compress.dart';
import 'package:image_picker/image_picker.dart' as image_picker;
import 'package:path/path.dart' as path;
import 'package:pessa_flow/common/common.dart';
import 'package:pessa_flow/constants/size.dart';
import 'package:pessa_flow/extensions/extension.dart';
import 'package:pessa_flow/generated/l10n.dart';
import 'package:pessa_flow/res/colors.dart';
import 'package:pessa_flow/widgets/widgets.dart';

import 'clickable_container.dart';

class ImagePicker {
  image_picker.ImageSource? imageSource;

  ImagePicker({this.imageSource});

  Future<File?> pickImage() async {
    try {
      var pickedImage = await _pickImage();
      if (pickedImage != null) {
        var compressedImage = await _compressFile(File(pickedImage.path));
        return compressedImage;
      }
    } on Exception catch (exception) {
      debugPrint("ImagePicker :: pickImage -> $exception");
    }
    return null;
  }

  Future<File?> pickImageWithoutCompression() async {
    try {
      var pickedImage = await _pickImage();
      if (pickedImage != null) return File(pickedImage.path);
    } on Exception catch (exception) {
      debugPrint("ImagePicker :: pickImageWithoutCompression -> $exception");
    }
    return null;
  }

  Future<image_picker.XFile?> _pickImage() async {
    imageSource ??= await chooseImageSource();
    return imageSource?.also((it) async {
      image_picker.XFile? pickedImage = await image_picker.ImagePicker().pickImage(source: it, imageQuality: 80);
      return pickedImage;
    });
  }

  Future<File?> _compressFile(File file) async {
    try {
      final extension = path.extension(file.path);
      CompressFormat compressFormat = extension.toLowerCase() == ".png" ? CompressFormat.png : CompressFormat.jpeg;
      final now = DateTime.now();
      final targetPath = (await tempDirectory()) + Platform.pathSeparator + "$now$extension";

      File? result = await FlutterImageCompress.compressAndGetFile(
        file.absolute.path,
        targetPath,
        quality: 80,
        format: compressFormat,
      );
      return result;
    } on Exception catch (exception) {
      debugPrint("ImagePicker :: _compressFile -> $exception");
    }
    return null;
  }

  Future<image_picker.ImageSource?> chooseImageSource() {
    return showDialog<image_picker.ImageSource>(
      context: App.context,
      builder: (context) =>
          Dialog(
        clipBehavior: Clip.hardEdge,
        child: ConstrainedBox(
          constraints: kDialogConstraints,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              ClickableContainer(
                splashColor: AppColor.greyLight.withOpacity(0.5),
                highlightColor: AppColor.greyLight.withOpacity(0.3),
                padding: const EdgeInsets.all(16),
                alignment: Alignment.center,
                onTap: () => Navigator.of(context).pop( image_picker.ImageSource.gallery),
                child: CommonText.semiBold(S.current.selectPhoto, size: 16),
              ),
              const Divider(),
              ClickableContainer(
                splashColor: AppColor.greyLight.withOpacity(0.5),
                highlightColor: AppColor.greyLight.withOpacity(0.3),
                padding: const EdgeInsets.all(16),
                alignment: Alignment.center,
                onTap: () =>  Navigator.of(context).pop( image_picker.ImageSource.camera),
                child: CommonText.semiBold(S.current.takePhoto, size: 16),
              ),
              const Divider(),
              ClickableContainer(
                splashColor: AppColor.greyLight.withOpacity(0.5),
                highlightColor: AppColor.greyLight.withOpacity(0.3),
                padding: const EdgeInsets.all(16),
                alignment: Alignment.center,
                onTap: () =>  Navigator.of(context).pop(),
                child: CommonText.semiBold(S.current.cancel, size: 16),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
