/*
import 'package:flutter/material.dart';
import 'package:pessa_flow/constants/size.dart';
import 'package:pessa_flow/res/colors.dart';
import 'package:pessa_flow/res/images.dart';
import 'package:pessa_flow/widgets/widgets.dart';
import 'package:pessa_flow/extensions/extension.dart';

class CommonBottomSheet extends StatelessWidget {
  final WidgetBuilder builder;
  final String title;
  final VoidCallback? onBackTap;
  final VoidCallback? onCloseTap;
  final bool hasTitle;
  final bool hasBackButton;
  final bool hasCloseButton;

  const CommonBottomSheet({
    required this.builder,
    this.title = "",
    this.onBackTap,
    this.onCloseTap,
    this.hasTitle = true,
    this.hasBackButton = false,
    this.hasCloseButton = true,
    Key? key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Stack(
      fit: StackFit.expand,
      children: [
        GestureDetector(onTap: () => Navigator.of(context).maybePop()),
        Align(
          alignment: Alignment.bottomCenter,
          child: ConstrainedBox(
            constraints: kLayoutConstraints,
            child: Card(
              margin: const EdgeInsets.fromLTRB(0, 64, 0, 0),
              shape: const RoundedRectangleBorder(
                borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
              ),
              clipBehavior: Clip.hardEdge,
              color: AppColor.white,
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  if (hasTitle)
                    Padding(
                      padding: const EdgeInsetsDirectional.fromSTEB(4, 4, 4, 4),
                      child: Row(
                        children: [
                          if (hasBackButton)
                            IconButton(
                              icon: const SquareSvgImageFromAsset(AppImage.imageBackBlue),
                              padding: const EdgeInsets.all(16),
                              onPressed: () => Navigator.of(context).pop(),
                              splashRadius: 24,
                            )
                          else
                            const SizeBoxV(52),
                          Expanded(
                            child: CommonText.bold(
                              title,
                              size: 20,
                              color: AppColor.primary,
                              textAlign: TextAlign.center,
                            ),
                          ),
                          if (hasCloseButton)
                            IconButton(
                              icon: const SquareSvgImageFromAsset(AppImage.imgCloseBlue),
                              padding: const EdgeInsets.all(16),
                              onPressed: onBackTap ?? () => Navigator.of(context).pop(),
                              splashRadius: 24,
                            )
                          else
                            const SizeBoxV(52),
                        ],
                      ),
                    ),
                  Flexible(
                    child: MediaQuery(
                      data: context.mediaQuery.copyWith(
                        padding: EdgeInsets.only(bottom: context.mediaQuery.padding.bottom),
                      ),
                      child: builder(context),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ],
    );
  }
}
*/
