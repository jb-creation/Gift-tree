import 'package:pessa_flow/common/common.dart';
import 'package:pessa_flow/constants/size.dart';
import 'package:pessa_flow/extensions/extension.dart';
import 'package:pessa_flow/generated/l10n.dart';
import 'package:pessa_flow/res/colors.dart';
import 'package:pessa_flow/res/images.dart';
import 'package:pessa_flow/widgets/widgets.dart';
import 'package:country_pickers/countries.dart' as country_list;
import 'package:country_pickers/country.dart';
import 'package:country_pickers/utils/utils.dart';
import 'package:flutter/material.dart';
import 'package:rxdart/rxdart.dart';

import 'clickable_container.dart';

class CountryCodePicker extends StatelessWidget {
  final Country selectedCountry;
  final void Function(Country country)? onSelectedCountryChanged;

  const CountryCodePicker({required this.selectedCountry, this.onSelectedCountryChanged, Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return IntrinsicWidth(
      child: ClickableContainer(
        padding: const EdgeInsets.symmetric(horizontal: 8),
        radius: 4,
        onTap: () {
          onSelectedCountryChanged?.let((it) async {
            var country = await CountryCodePickerSheet.show(context, selectedCountryCode: selectedCountry.phoneCode);
            country?.let((country) => onSelectedCountryChanged?.call(country));
          });
        },
        clipBehavior: Clip.hardEdge,
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            ClipRRect(
              borderRadius: BorderRadius.circular(4),
              clipBehavior: Clip.hardEdge,
              child: Image.asset(
                getFlagPathFromISOCode(selectedCountry.isoCode),
                height: 20,
                width: 28,
                fit: BoxFit.cover,
                package: "country_pickers",
              ),
            ),
            const SizeBoxV(8),
            CommonText.medium("+${selectedCountry.phoneCode}", size: 16),
          ],
        ),
      ),
    );
  }
}

class CountryCodePickerSheet extends StatefulWidget {
  final String selectedCountryCode;

  const CountryCodePickerSheet({this.selectedCountryCode = "91", Key? key}) : super(key: key);

  static Future<Country?> show(BuildContext context, {String selectedCountryCode = "91"}) async {
    var result = await showModalBottomSheet<Country>(
      context: context,
      isScrollControlled: true,
      builder: (context) => CountryCodePickerSheet(selectedCountryCode: selectedCountryCode),
    );
    return result;
  }

  @override
  _CountryCodePickerSheetState createState() => _CountryCodePickerSheetState();
}

class _CountryCodePickerSheetState extends State<CountryCodePickerSheet> {
  late Country _selectedCountry;
  late PublishSubject<String> _searchTextSubject;
  late PublishSubject<Iterable<Country>> _countryListSubject;
  late TextEditingController _searchController;

  @override
  void initState() {
    WidgetsBinding.instance
        ?.addPostFrameCallback((_) => setState(() => _countryListSubject.add(country_list.countryList)));
    _searchTextSubject = PublishSubject<String>()
      ..stream.distinct().debounceTime(const Duration(milliseconds: 600)).listen(onSearch);
    _countryListSubject = PublishSubject<Iterable<Country>>()..add([]);
    _selectedCountry =
        country_list.countryList.where((element) => element.phoneCode == widget.selectedCountryCode).first;
    _searchController = TextEditingController();
    super.initState();
  }

  void onSearch(String searchText) {
    if (searchText.isEmpty) {
      _countryListSubject.add(country_list.countryList);
    } else {
      _countryListSubject.add(country_list.countryList.where((element) =>
          element.name.toLowerCase().contains(searchText) || element.phoneCode.toLowerCase().contains(searchText)));
    }
  }

  @override
  Widget build(BuildContext context) {
    return ConstrainedBox(
      constraints: BoxConstraints(maxHeight: MediaQuery.of(context).size.height - 84, maxWidth: kMaxLayoutWidth),
      child: Column(
        children: [
          Container(
            margin: const EdgeInsets.fromLTRB(16, 8, 16, 0),
            width: 64,
            height: 4,
            decoration: BoxDecoration(color: AppColor.grey.withAlpha(150), borderRadius: BorderRadius.circular(4)),
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
            child: TextFormField(
              controller: _searchController,
              textInputAction: TextInputAction.search,
              keyboardType: TextInputType.text,
              style: const TextStyle(color: AppColor.textPrimary, fontWeight: FontWeight.w500, fontSize: 16),
              onChanged: (value) => _searchTextSubject.add(value),
              decoration: InputDecoration(
                contentPadding: const EdgeInsets.symmetric(vertical: 14, horizontal: 14),
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(40), borderSide: BorderSide.none),
                disabledBorder:
                    OutlineInputBorder(borderRadius: BorderRadius.circular(40), borderSide: BorderSide.none),
                enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(40), borderSide: BorderSide.none),
                focusedBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(40), borderSide: const BorderSide(color: AppColor.primary)),
                filled: true,
                fillColor: AppColor.greyLight,
                hintText: S.of(context).searchHere,
                prefixIcon: IconButton(
                  icon: const SquareSvgImageFromAsset(AppImage.searchIcon, size: 20),
                  onPressed: () => FocusScope.of(context).unfocus(),
                  splashRadius: 24,
                ),
              ),
            ),
          ),
          Expanded(
            child: StreamBuilder<Iterable<Country>>(
              stream: _countryListSubject,
              builder: (context, snapshot) {
                return ListView.builder(
                  padding: EdgeInsets.zero,
                  itemCount: snapshot.hasData ? snapshot.data!.length : 0,
                  itemBuilder: (context, index) {
                    var country = snapshot.data!.elementAt(index);
                    return ListTile(
                      selectedTileColor: AppColor.greyLight,
                      selected: country.phoneCode == _selectedCountry.phoneCode,
                      title: Row(
                        children: [
                          ClipRRect(
                            borderRadius: BorderRadius.circular(4),
                            clipBehavior: Clip.hardEdge,
                            child: Image.asset(
                              CountryPickerUtils.getFlagImageAssetPath(country.isoCode),
                              height: 20.0,
                              width: 28.0,
                              fit: BoxFit.cover,
                              package: "country_pickers",
                            ),
                          ),
                          const SizeBoxV(8),
                          Expanded(
                            child: FittedBox(
                              alignment: AlignmentDirectional.centerStart,
                              fit: BoxFit.scaleDown,
                              child: CommonText.medium("+${country.phoneCode}", size: 16),
                            ),
                            flex: 1,
                          ),
                          const SizeBoxV(8),
                          Expanded(child: CommonText.medium(country.name, size: 16), flex: 4),
                        ],
                      ),
                      onTap: () {
                        _selectedCountry = country;
                        onSearch(_searchController.text);
                      },
                    );
                  },
                );
              },
            ),
          ),
          Padding(
            padding: EdgeInsets.fromLTRB(16, 16, 16, 16 + MediaQuery.of(context).padding.bottom),
            child: CommonButton(
              onPressed: () => Navigator.of(context).pop(_selectedCountry),
              label: "Save",
            ),
          )
        ],
      ),
    );
  }
}
