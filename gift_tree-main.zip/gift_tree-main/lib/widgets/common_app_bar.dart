import 'package:pessa_flow/extensions/extension.dart';
import 'package:pessa_flow/res/colors.dart';
import 'package:pessa_flow/res/images.dart';
import 'package:pessa_flow/widgets/widgets.dart';
import 'package:flutter/material.dart';

class CommonAppBar extends StatelessWidget with PreferredSizeWidget {
  final String title;
  final VoidCallback? onBackTap;
  final PreferredSizeWidget? bottom;
  final bool hasBackIcon;
  final Widget? actionIcon;
  final String? leadingIcon;

  const CommonAppBar({
    required this.title,
    this.onBackTap,
    this.bottom,
    this.hasBackIcon = true,
    this.actionIcon,
    this.leadingIcon,
    Key? key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Material(
      color: AppColor.transparent,
      child: Column(
        children: [
          SizeBoxH(context.topPadding),
          Expanded(
            child: Row(
              children: [
                const SizeBoxV(4),
                hasBackIcon
                    ? InkWell(
                        onTap: onBackTap,
                        child: const Padding(
                          padding: EdgeInsets.fromLTRB(8.0, 0.0, 8.0, 0.0),
                          child: CircleImageFromAsset(
                            AppImage.back,
                            size: 42,
                          ),
                        ),
                      )
                    : const SizeBoxV(48),
                Expanded(
                  child: CommonText.bold(title,
                      size: 18,
                      color: AppColor.textPrimary,
                      textAlign: TextAlign.center),
                ),
                actionIcon ?? const SizeBoxV(48),
              ],
            ),
          ),
          if (bottom != null) bottom!,
        ],
      ),
    );
  }

  @override
  Size get preferredSize =>
      Size.fromHeight(56 + (bottom?.preferredSize.height ?? 0));
}

class CommonAppBarGrey extends StatelessWidget with PreferredSizeWidget {
  final String title;
  final VoidCallback? onBackTap;
  final PreferredSizeWidget? bottom;
  final bool hasBackIcon;
  final Widget? actionIcon;
  final String? leadingIcon;

  const CommonAppBarGrey({
    required this.title,
    this.onBackTap,
    this.bottom,
    this.hasBackIcon = true,
    this.actionIcon,
    this.leadingIcon,
    Key? key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Material(
      color: AppColor.transparent,
      child: Column(
        children: [
          SizeBoxH(context.topPadding),
          Expanded(
            child: Row(
              children: [
                const SizeBoxV(4),
                hasBackIcon
                    ? InkWell(
                        onTap: onBackTap,
                        child: const Padding(
                          padding: EdgeInsets.fromLTRB(8.0, 0.0, 8.0, 0.0),
                          child: CircleImageFromAsset(
                            AppImage.backGrey,
                            size: 42,
                          ),
                        ),
                      )
                    : const SizeBoxV(48),
                Expanded(
                  child: CommonText.bold(title,
                      size: 24,
                      color: AppColor.textPrimary,
                      textAlign: TextAlign.center),
                ),
                actionIcon ?? const SizeBoxV(48),
              ],
            ),
          ),
          if (bottom != null) bottom!,
        ],
      ),
    );
  }

  @override
  Size get preferredSize =>
      Size.fromHeight(56 + (bottom?.preferredSize.height ?? 0));
}

class CommonAppBarBlack extends StatelessWidget with PreferredSizeWidget {
  final String title;
  final VoidCallback? onBackTap;
  final PreferredSizeWidget? bottom;
  final bool hasBackIcon;
  final Widget? actionIcon;
  final String? leadingIcon;

  const CommonAppBarBlack({
    required this.title,
    this.onBackTap,
    this.bottom,
    this.hasBackIcon = true,
    this.actionIcon,
    this.leadingIcon,
    Key? key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Material(
      color: AppColor.primary,
      child: Column(
        children: [
          SizeBoxH(context.topPadding * 1.5),
          Expanded(
            child: Row(
              children: [
                const SizeBoxV(4),
                hasBackIcon
                    ? InkWell(
                        onTap: onBackTap,
                        child: const Padding(
                          padding: EdgeInsets.fromLTRB(8.0, 0.0, 8.0, 0.0),
                          child: CircleImageFromAsset(
                            AppImage.backBlack,
                            size: 42,
                          ),
                        ),
                      )
                    : const SizeBoxV(48),
                Expanded(
                  child: CommonText.bold(title,
                      size: 22,
                      color: AppColor.white,
                      textAlign: TextAlign.center),
                ),
                actionIcon ?? const SizeBoxV(48),
              ],
            ),
          ),
          if (bottom != null) bottom!,
        ],
      ),
    );
  }

  @override
  Size get preferredSize =>
      Size.fromHeight(80 + (bottom?.preferredSize.height ?? 0));
}

class CommonAppBarClose extends StatelessWidget with PreferredSizeWidget {
  final String title;
  final VoidCallback? onBackTap;
  final PreferredSizeWidget? bottom;
  final bool hasBackIcon;
  final Widget? actionIcon;
  final String? leadingIcon;

  const CommonAppBarClose({
    required this.title,
    this.onBackTap,
    this.bottom,
    this.hasBackIcon = true,
    this.actionIcon,
    this.leadingIcon,
    Key? key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Material(
      color: AppColor.transparent,
      child: Column(
        children: [
          SizeBoxH(context.topPadding),
          Expanded(
            child: Row(
              children: [
                const SizeBoxV(4),
                hasBackIcon
                    ? InkWell(
                        onTap: onBackTap,
                        child: const Padding(
                          padding: EdgeInsets.fromLTRB(8.0, 0.0, 8.0, 0.0),
                          child: CircleImageFromAsset(
                            AppImage.close,
                            size: 42,
                          ),
                        ),
                      )
                    : const SizeBoxV(48),
                Expanded(
                  child: CommonText.bold(title,
                      size: 24,
                      color: AppColor.textPrimary,
                      textAlign: TextAlign.center),
                ),
                actionIcon ?? const SizeBoxV(48),
              ],
            ),
          ),
          if (bottom != null) bottom!,
        ],
      ),
    );
  }

  @override
  Size get preferredSize =>
      Size.fromHeight(56 + (bottom?.preferredSize.height ?? 0));
}
