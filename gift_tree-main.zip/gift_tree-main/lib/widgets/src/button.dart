part of '../widgets.dart';

class CommonButton extends StatelessWidget {
  final String? label;
  final EdgeInsetsGeometry padding;
  final VoidCallback? onPressed;
  final double textSize;
  final Color labelColor;
  final Color bgColor;
  final Widget? child;

  const CommonButton({
    required this.onPressed,
    this.label,
    this.child,
    this.padding = const EdgeInsets.all(16),
    this.textSize = 18.0,
    this.labelColor = AppColor.white,
    this.bgColor = AppColor.red,
    Key? key,
  })  : assert(child == null || label == null, "cannot assign both at once."),
        super(key: key);

  @override
  Widget build(BuildContext context) {
    return ElevatedButton(
      onPressed: onPressed,
      clipBehavior: Clip.hardEdge,
      style: ButtonStyle(padding: MaterialStateProperty.all(padding)).copyWith(
        backgroundColor: MaterialStateProperty.all(bgColor)
      ),
      child: Center(
        child: child ??
            CommonText.bold(
              label!,
              size: textSize,
              color: labelColor,
              textAlign: TextAlign.center,
            ),
      ),
    );
  }
}

