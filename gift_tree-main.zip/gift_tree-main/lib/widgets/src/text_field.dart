part of '../widgets.dart';

class CommonTextField extends StatelessWidget {
  final TextEditingController controller;
  final String hintText;
  final String labelText;
  final Color labelColor;
  final TextInputType keyboardType;
  final bool obscure;
  final TextInputAction inputAction;
  final FormFieldValidator<String>? validator;
  final GlobalKey<FormFieldState>? _fieldKey;
  final ValueChanged<String>? fieldSubmitted;
  final FocusNode? focus;
  final ValueChanged<String>? onChanged;
  final Widget? prefix;
  final Widget? suffix;
  final Widget? prefixIcon;
  final Widget? suffixIcon;
  final int maxLines;
  final int minLines;
  final List<TextInputFormatter> inputFormatters;
  final bool isReadOnly;
  final TextAlign textAlign;
  final VoidCallback? onTap;
  final BoxConstraints iconConstraints;
  final Color fillColor;
  final Color cursorColor;
  final Color textColor;
  final Color borderColor;

  const CommonTextField({
    required this.controller,
    this.labelText = "",
    this.labelColor =  AppColor.textPrimary,
    GlobalKey<FormFieldState>? globalKey,
    this.keyboardType = TextInputType.text,
    this.obscure = false,
    this.inputAction = TextInputAction.next,
    this.validator,
    this.fieldSubmitted,
    this.focus,
    this.onChanged,
    this.prefix,
    this.suffix,
    this.prefixIcon,
    this.suffixIcon,

    this.inputFormatters = const [],
    this.maxLines = 1,
    this.minLines = 1,
    this.isReadOnly = false,
    this.hintText = "",
    this.textAlign = TextAlign.start,
    this.onTap,
    this.iconConstraints = const BoxConstraints(maxWidth: 120),
    this.fillColor = AppColor.textBackGround,
    this.cursorColor = AppColor.white,
    this.textColor = AppColor.white,
    this.borderColor =  AppColor.textBackGround,
    Key? key,
  })  : _fieldKey = globalKey,
        super(key: key);

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        if (labelText.isNotEmpty) ...[
          CommonText.medium(labelText, size: 14, color:labelColor),
          const SizeBoxH(12),
        ],
        TextFormField(
          onTap: onTap,
          key: _fieldKey,
          validator: validator,
          obscuringCharacter: "•",
          textInputAction: inputAction,
          onFieldSubmitted: fieldSubmitted,
          controller: controller,
          focusNode: focus,
          obscureText: obscure,
          onChanged: onChanged,
          keyboardType: keyboardType,
          autovalidateMode: AutovalidateMode.onUserInteraction,
          style: TextStyle(
            color: textColor,
            fontWeight: FontWeight.w500,
            fontSize: 16,
            fontFamily: kFontFamily,
          ),
          textAlign: textAlign,
          maxLines: maxLines,
          minLines: minLines,
          readOnly: isReadOnly,
          cursorColor: cursorColor,
          inputFormatters: inputFormatters,
          decoration: InputDecoration(
              filled: true,
              fillColor: fillColor,
              hintText: hintText,
              hintStyle: const TextStyle(
                color: AppColor.textPrimaryMedium,
                fontWeight: FontWeight.w500,
                fontSize: 16,
                fontFamily: kFontFamily,
              ),
              prefix: prefix,
              suffix: suffix,
              prefixIcon: prefixIcon,
              suffixIcon: suffixIcon,
              prefixIconConstraints: iconConstraints,
              suffixIconConstraints: iconConstraints,
              border: InputBorder.none,
              focusedBorder: OutlineInputBorder(
                  borderSide: BorderSide(
                    color: borderColor,
                    width: 1.0,
                  ),
                  borderRadius: const BorderRadius.all(Radius.circular(12.0))),
              enabledBorder: OutlineInputBorder(
                  borderSide: BorderSide(
                    color: borderColor,
                    width: 1.0,
                  ),
                  borderRadius: const BorderRadius.all(Radius.circular(12.0)))),
        ),
      ],
    );
  }
}

class CommonTextFieldEmpty extends StatelessWidget {
  final TextEditingController controller;
  final String hintText;
  final String labelText;
  final TextInputType keyboardType;
  final bool obscure;
  final TextInputAction inputAction;
  final FormFieldValidator<String>? validator;
  final GlobalKey<FormFieldState>? _fieldKey;
  final ValueChanged<String>? fieldSubmitted;
  final FocusNode? focus;
  final ValueChanged<String>? onChanged;
  final Widget? prefix;
  final Widget? suffix;
  final Widget? prefixIcon;
  final Widget? suffixIcon;
  final int maxLines;
  final int minLines;
  final List<TextInputFormatter> inputFormatters;
  final bool isReadOnly;
  final TextAlign textAlign;
  final VoidCallback? onTap;
  final BoxConstraints iconConstraints;
  final Color fillColor;
  final Color cursorColor;
  final Color textColor;

  const CommonTextFieldEmpty({
    required this.controller,
    this.labelText = "",
    GlobalKey<FormFieldState>? globalKey,
    this.keyboardType = TextInputType.text,
    this.obscure = false,
    this.inputAction = TextInputAction.next,
    this.validator,
    this.fieldSubmitted,
    this.focus,
    this.onChanged,
    this.prefix,
    this.suffix,
    this.prefixIcon,
    this.suffixIcon,
    this.inputFormatters = const [],
    this.maxLines = 1,
    this.minLines = 1,
    this.isReadOnly = false,
    this.hintText = "",
    this.textAlign = TextAlign.start,
    this.onTap,
    this.iconConstraints = const BoxConstraints(maxWidth: 120),
    this.fillColor = AppColor.textBackGround,
    this.cursorColor = AppColor.white,
    this.textColor = AppColor.white,

    Key? key,
  })  : _fieldKey = globalKey,
        super(key: key);

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        if (labelText.isNotEmpty) ...[
          CommonText.bold(labelText, size: 14, color: AppColor.primary),
        ],
        TextFormField(
          onTap: onTap,
          key: _fieldKey,
          validator: validator,
          obscuringCharacter: "•",
          textInputAction: inputAction,
          onFieldSubmitted: fieldSubmitted,
          controller: controller,
          focusNode: focus,
          obscureText: obscure,
          onChanged: onChanged,
          keyboardType: keyboardType,
          autovalidateMode: AutovalidateMode.onUserInteraction,
          style: TextStyle(
            color: textColor,
            fontWeight: FontWeight.w500,
            fontSize: 16,
            fontFamily: kFontFamily,
          ),
          textAlign: textAlign,
          maxLines: maxLines,
          minLines: minLines,
          readOnly: isReadOnly,
          cursorColor: cursorColor,
          inputFormatters: inputFormatters,
          decoration: InputDecoration(
              filled: true,
              fillColor: fillColor,
              hintText: hintText,
              contentPadding: EdgeInsets.zero,
              hintStyle: const TextStyle(
                color: AppColor.textPrimaryMedium,
                fontWeight: FontWeight.w500,
                fontSize: 16,
                fontFamily: kFontFamily,
              ),
              prefix: prefix,
              suffix: suffix,
              prefixIcon: prefixIcon,
              suffixIcon: suffixIcon,
              prefixIconConstraints: iconConstraints,
              suffixIconConstraints: iconConstraints,
              border: InputBorder.none,
              enabledBorder: InputBorder.none,
              focusedBorder: InputBorder.none,
          ),
        ),
      ],
    );
  }
}
