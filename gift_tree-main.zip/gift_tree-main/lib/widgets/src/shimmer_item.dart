import 'package:pessa_flow/res/colors.dart';
import 'package:pessa_flow/widgets/widgets.dart';
import 'package:flutter/material.dart';
import 'package:pessa_flow/res/colors.dart';
import 'package:pessa_flow/widgets/widgets.dart';
import 'package:shimmer/shimmer.dart';

class ListItemShimmer extends StatelessWidget {
  const ListItemShimmer({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
      child: Row(
        children: [
          ClipRRect(
            borderRadius: BorderRadius.circular(16),
            clipBehavior: Clip.hardEdge,
            child: Shimmer.fromColors(
              baseColor: AppColor.greyLight,
              highlightColor: AppColor.white,
              child: const Card(child: SizedBox.square(dimension: 52)),
            ),
          ),
          const SizeBoxV(12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Shimmer.fromColors(
                  baseColor: AppColor.greyLight,
                  highlightColor: AppColor.white,
                  child: Container(color: AppColor.white, width: 160, height: 16),
                ),
                const SizeBoxH(8),
                Shimmer.fromColors(
                  baseColor: AppColor.greyLight,
                  highlightColor: AppColor.white,
                  child: Container(color: AppColor.white, width: 200, height: 16),
                ),
              ],
            ),
          )
        ],
      ),
    );
  }
}

class CardShimmerItem extends StatelessWidget {
  const CardShimmerItem({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Card(
      elevation: 0,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(16),
        side: const BorderSide(color: AppColor.greyLight),
      ),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Row(
          children: [
            Shimmer.fromColors(
              baseColor: AppColor.greyLight,
              highlightColor: AppColor.white,
              child: const Card(
                color: AppColor.greyLight,
                elevation: 0,
                child: Padding(
                  padding: EdgeInsets.all(12),
                  child: SizedBox.square(dimension: 24),
                ),
              ),
            ),
            const SizeBoxV(12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Shimmer.fromColors(
                    baseColor: AppColor.greyLight,
                    highlightColor: AppColor.white,
                    child: Container(color: AppColor.white, width: 120, height: 16),
                  ),
                  const SizeBoxH(8),
                  Shimmer.fromColors(
                    baseColor: AppColor.greyLight,
                    highlightColor: AppColor.white,
                    child: Container(color: AppColor.white, width: 160, height: 16),
                  ),
                ],
              ),
            )
          ],
        ),
      ),
    );
  }
}
