import 'package:pessa_flow/constants/size.dart';
import 'dart:math' as math;
import 'dart:ui';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class ShimmerList extends StatefulWidget {
  final int itemCount;
  final IndexedWidgetBuilder itemBuilder;
  final IndexedWidgetBuilder shimmerBuilder;
  final IndexedWidgetBuilder? separatorBuilder;
  final ScrollPhysics? physics;
  final ScrollController? controller;
  final Clip clipBehavior;
  final EdgeInsets? padding;
  final bool shrinkWrap;
  final Future<void> Function()? onRefresh;
  final Future<void> Function() onLoadMore;
  final bool reachAtEnd;
  final bool isLoading;
  final Widget? emptyDataView;

  const ShimmerList({
    required this.itemCount,
    required this.itemBuilder,
    required this.shimmerBuilder,
    required this.onLoadMore,
    this.separatorBuilder,
    this.physics,
    this.controller,
    this.clipBehavior = Clip.hardEdge,
    this.padding,
    this.shrinkWrap = false,
    this.onRefresh,
    this.reachAtEnd = false,
    this.isLoading = false,
    this.emptyDataView,
    Key? key,
  }) : super(key: key);

  @override
  _ShimmerListState createState() => _ShimmerListState();
}

class _ShimmerListState extends State<ShimmerList> {
  Future<void> onRefresh() async {
    return widget.onRefresh?.call();
  }

  void onScrollEnd(ScrollNotification notification) {
    if (notification.metrics.pixels >= notification.metrics.maxScrollExtent &&
        !widget.isLoading &&
        widget.itemCount > 0 &&
        !widget.reachAtEnd) {
      widget.onLoadMore.call();
    }
  }

  bool get hasSeparator => widget.separatorBuilder != null;

  int get childCount {
    var count = 0;
    if (widget.itemCount == 0) {
      count = widget.isLoading ? 3 : 0;
    } else {
      count = widget.itemCount + (widget.isLoading ? 5 : 0);
    }
    return hasSeparator ? ((count * 2) - 1) : count;
  }

  @override
  Widget build(BuildContext context) {
    var padding = widget.padding ?? MediaQuery.of(context).padding;
    var topPadding = padding.copyWith(bottom: 0);
    var bottomPadding = padding.copyWith(top: 0);
    return NotificationListener<ScrollNotification>(
      onNotification: (notification) {
        onScrollEnd(notification);
        return false;
      },
      child: CustomScrollView(
        shrinkWrap: widget.shrinkWrap,
        controller: widget.controller,
        physics: widget.physics,
        clipBehavior: widget.clipBehavior,
        slivers: [
          if (widget.onRefresh != null)
            SliverPadding(
              padding: topPadding,
              sliver: CupertinoSliverRefreshControl(
                onRefresh: widget.onRefresh,
                refreshIndicatorExtent: 72,
                refreshTriggerPullDistance: 120,
                builder: (context, refreshState, pulledExtent,
                    refreshTriggerPullDistance, refreshIndicatorExtent) {
                  switch (refreshState) {
                    case RefreshIndicatorMode.inactive:
                      return const SizedBox.shrink();
                    case RefreshIndicatorMode.drag:
                      return CircleLoader(
                          value: pulledExtent / refreshIndicatorExtent);
                    case RefreshIndicatorMode.armed:
                      return const CircleLoader(value: 1.0);
                    case RefreshIndicatorMode.refresh:
                    case RefreshIndicatorMode.done:
                      return const CircleLoader();
                  }
                },
              ),
            ),
          !widget.isLoading && widget.itemCount == 0
              ? SliverFillRemaining(
                  child: Center(
                    child: Container(
                      constraints: kLayoutConstraints,
                      padding:
                          widget.onRefresh == null ? padding : bottomPadding,
                      child: widget.emptyDataView,
                    ),
                  ),
                )
              : SliverPadding(
                  padding: widget.onRefresh == null ? padding : bottomPadding,
                  sliver: SliverList(
                    delegate: SliverChildBuilderDelegate(
                      (context, index) {
                        if (!hasSeparator) {
                          if (index >= widget.itemCount) {
                            return widget.shimmerBuilder(context, index);
                          } else {
                            return widget.itemBuilder(context, index);
                          }
                        } else {
                          var initialIndex = index ~/ 2;
                          if (index.isOdd) {
                            return widget.separatorBuilder
                                ?.call(context, initialIndex);
                          } else {
                            if (initialIndex >= widget.itemCount) {
                              return widget.shimmerBuilder(
                                  context, initialIndex);
                            } else {
                              return widget.itemBuilder(context, initialIndex);
                            }
                          }
                        }
                      },
                      childCount: childCount,
                      semanticIndexCallback: (widget, index) =>
                          hasSeparator ? index ~/ 2 : index,
                    ),
                  ),
                )
        ],
      ),
    );
  }
}

class CircleLoader extends StatefulWidget {
  final Color? color;
  final double? value;
  final bool hasShadow;

  const CircleLoader({Key? key, this.color, this.value, this.hasShadow = true})
      : super(key: key);

  @override
  _CircleLoaderState createState() => _CircleLoaderState();
}

class _CircleLoaderState extends State<CircleLoader>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 1000));
    if (widget.value == null) {
      _controller.repeat();
    } else {
      _controller.value = widget.value!;
    }
  }

  @override
  void didUpdateWidget(covariant CircleLoader oldWidget) {
    if (widget.value == null) {
      _controller.repeat();
    } else {
      _controller.stop();
      _controller.value = widget.value!;
    }
    super.didUpdateWidget(oldWidget);
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Material(
      clipBehavior: Clip.hardEdge,
      type: MaterialType.circle,
      color: Colors.transparent,
      child: SizedBox.square(
        dimension: 64,
        child: AspectRatio(
          child: AnimatedBuilder(
            animation: _controller,
            builder: (context, _) {
              return CustomPaint(
                painter: _CircleLoaderPainter(
                  value: _controller.value,
                  color: widget.color ?? Theme.of(context).primaryColor,
                ),
                foregroundPainter: _CircleLoaderPainter(
                  value: _controller.value,
                  color: widget.color ?? Theme.of(context).primaryColor,
                ),
                child: widget.hasShadow
                    ? BackdropFilter(
                        filter: ImageFilter.blur(sigmaX: 1, sigmaY: 1),
                        child: const SizedBox.square(dimension: 56),
                      )
                    : const SizedBox.square(dimension: 56),
              );
            },
          ),
          aspectRatio: 1,
        ),
      ),
    );
  }
}

class _CircleLoaderPainter extends CustomPainter {
  double value;
  Color color;

  _CircleLoaderPainter({required this.value, required this.color});

  @override
  void paint(Canvas canvas, Size size) {
    var center = Offset(size.width / 2, size.height / 2);
    var backgroundPaint = Paint()
      ..color = color.withAlpha(50)
      ..style = PaintingStyle.stroke
      ..strokeCap = StrokeCap.round
      ..strokeWidth = 8;
    var foregroundPaint = Paint()
      ..color = color
      ..style = PaintingStyle.stroke
      ..strokeCap = StrokeCap.round
      ..strokeWidth = 8;
    canvas.drawCircle(center, 20, backgroundPaint);
    var angle = (math.pi * 2) * value;
    canvas.drawArc(Rect.fromCircle(center: center, radius: 20), angle, math.pi,
        false, foregroundPaint);
  }

  @override
  bool shouldRepaint(covariant _CircleLoaderPainter oldDelegate) => true;
}
