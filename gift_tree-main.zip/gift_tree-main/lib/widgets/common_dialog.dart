import 'package:pessa_flow/constants/size.dart';
import 'package:pessa_flow/extensions/extension.dart';
import 'package:pessa_flow/res/colors.dart';
import 'package:flutter/material.dart';

import 'widgets.dart';

class CommonDialog extends StatelessWidget {
  final String title, description, positiveButtonText, negativeButtonText, bottomButton;
  final bool dismissible;
  final VoidCallback? positiveButtonTap, negativeButtonTap, onBottomButtonTap;
  final String image;

  static Future<T?> show<T>({
    required String title,
    required String description,
    String positiveButtonText = "",
    String negativeButtonText = "",
    String bottomButton = "",
    bool dismissible = false,
    VoidCallback? positiveButtonTap,
    VoidCallback? negativeButtonTap,
    VoidCallback? onBottomButtonTap,
    String image = "",
  }) {
    return showDialog(
      context: App.context,
      barrierDismissible: dismissible,
      builder: (context) => CommonDialog(
        title: title,
        description: description,
        positiveButtonText: positiveButtonText,
        negativeButtonText: negativeButtonText,
        bottomButton: bottomButton,
        positiveButtonTap: positiveButtonTap,
        negativeButtonTap: negativeButtonTap,
        onBottomButtonTap: onBottomButtonTap,
        dismissible: dismissible,
        image: image,
      ),
    );
  }

  const CommonDialog({
    required this.title,
    required this.description,
    this.positiveButtonText = "",
    this.negativeButtonText = "",
    this.bottomButton = "",
    this.positiveButtonTap,
    this.negativeButtonTap,
    this.onBottomButtonTap,
    this.dismissible = false,
    this.image = "",
    Key? key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    var content = Stack(
      children: [
        Card(
          elevation: 8,
          margin: EdgeInsets.only(top: image.isEmpty ? 0 : 36),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
          color: AppColor.white,
          child: Container(
            width: double.infinity,
            padding: EdgeInsetsDirectional.fromSTEB(24, image.isEmpty ? 24 : 60, 24, 8),
            constraints: kDialogConstraints,
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                CommonText.medium(title, size: 18, textAlign: TextAlign.center),
                Flexible(
                  child: Padding(
                    padding: const EdgeInsets.symmetric(vertical: 16),
                    child: CommonText.medium(
                      description,
                      size: 13,
                      color: AppColor.textPrimaryLight,
                      textAlign: TextAlign.center,
                    ),
                  ),
                ),
                if (positiveButtonText.isNotEmpty)
                  TextButton(
                    style: TextButton.styleFrom(
                      padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 8),
                    ),
                    onPressed: positiveButtonTap ?? () => Navigator.pop(context, true),
                    child: CommonText.bold(
                      positiveButtonText,
                      size: 16.0,
                      color: AppColor.primary,
                      textAlign: TextAlign.center,
                    ),
                  ),
                if (negativeButtonText.isNotEmpty)
                  TextButton(
                    style: TextButton.styleFrom(
                      primary: AppColor.red,
                      padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 8),
                    ),
                    onPressed: negativeButtonTap ?? () => Navigator.pop(context, false),
                    child: CommonText.bold(
                      negativeButtonText,
                      size: 16.0,
                      color: AppColor.red,
                      textAlign: TextAlign.center,
                    ),
                  ),
              ],
            ),
          ),
        ),
        if (image.isNotEmpty)
          Align(
            alignment: Alignment.topCenter,
            child: Card(
              elevation: 8,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: SquareSvgImageFromAsset(image, size: 40),
              ),
            ),
          ),
      ],
    );

    return WillPopScope(
      onWillPop: () => Future.value(dismissible),
      child: Dialog(
        backgroundColor: AppColor.transparent,
        elevation: 0,
        insetPadding: const EdgeInsets.symmetric(vertical: 16, horizontal: 24),
        child: bottomButton.isEmpty
            ? IntrinsicHeight(child: content)
            : Stack(
                fit: StackFit.expand,
                children: [
                  Column(
                    children: [
                      const Spacer(),
                      content,
                      const Spacer(),
                    ],
                  ),
                  Positioned(
                    bottom: 0,
                    left: 0,
                    right: 0,
                    child: ElevatedButtonTheme(
                      data: ElevatedButtonThemeData(
                        style: ButtonStyle(
                          backgroundColor: MaterialStateProperty.all(AppColor.white),
                          shape: MaterialStateProperty.all(RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(12),
                          )),
                        ),
                      ),
                      child: CommonButton(
                        onPressed: onBottomButtonTap,
                        label: bottomButton,
                        labelColor: AppColor.primary,
                      ),
                    ),
                  )
                ],
              ),
      ),
    );
  }
}
