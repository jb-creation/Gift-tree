part of 'notification_settings_view.dart';

class NotificationSettingsState extends Equatable {
  List<NotificationSettingsData> listSettings;

  NotificationSettingsState({this.listSettings = const []});

  @override
  List<Object?> get props => [listSettings];

  NotificationSettingsState copyWith({List<NotificationSettingsData>? listSettings}) {
    return NotificationSettingsState(
      listSettings: listSettings ?? this.listSettings,
    );
  }
}
