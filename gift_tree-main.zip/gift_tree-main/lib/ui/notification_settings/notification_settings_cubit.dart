part of 'notification_settings_view.dart';

class NotificationSettingsCubit extends BaseCubit<NotificationSettingsState> {
  NotificationSettingsCubit(BuildContext context)
      : super(context, NotificationSettingsState()) {
    Timer.run(() {
      emit(NotificationSettingsState(
        listSettings: [
          NotificationSettingsData(
              id: 1, title: "Payment Success", selected: true),
          NotificationSettingsData(
              id: 2, title: "Payment Failure", selected: false),
          NotificationSettingsData(
              id: 3, title: "Incoming Transaction", selected: false),
          NotificationSettingsData(
              id: 4, title: "Outgoing Transaction", selected: true),
          NotificationSettingsData(
              id: 5, title: "Service Updates & Tips", selected: false),
        ],
      ));
    });
  }

  void onChangeSwitch(int index, bool selection) {
    var listSettings = List<NotificationSettingsData>.from(state.listSettings);
    listSettings[index] = listSettings[index].copyWith(selection: selection);
    emit(state.copyWith(listSettings: listSettings));
  }
}
