import 'dart:async';

import 'package:equatable/equatable.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:pessa_flow/common/validator.dart';
import 'package:pessa_flow/generated/l10n.dart';
import 'package:pessa_flow/model/model.dart';
import 'package:pessa_flow/res/colors.dart';
import 'package:pessa_flow/res/images.dart';
import 'package:pessa_flow/ui/main/main_view.dart';
import 'package:pessa_flow/utils/base_cubit.dart';
import 'package:pessa_flow/widgets/common_app_bar.dart';
import 'package:pessa_flow/widgets/widgets.dart';

part 'notification_settings_state.dart';

part 'notification_settings_cubit.dart';

class NotificationSettingsView extends StatefulWidget {
  const NotificationSettingsView({Key? key}) : super(key: key);

  @override
  _NotificationSettingsViewState createState() =>
      _NotificationSettingsViewState();
}

class _NotificationSettingsViewState extends State<NotificationSettingsView> {
  @override
  Widget build(BuildContext context) {
    var initialState =
        BlocProvider.of<NotificationSettingsCubit>(context).state;
    return Scaffold(
      appBar: CommonAppBarBlack(
        title: S.of(context).settings,
        onBackTap: () => Navigator.of(context).pop(),
      ),
      body: BlocBuilder<NotificationSettingsCubit, NotificationSettingsState>(
        buildWhen: (previous, current) =>
            previous.listSettings != current.listSettings,
        builder: (context, state) {
          return ListView.separated(
              itemCount: state.listSettings.length,
              physics: const BouncingScrollPhysics(
                  parent: AlwaysScrollableScrollPhysics()),
              controller: ScrollController(),
              separatorBuilder: (context, index) => const Divider(
                    indent: 16,
                    endIndent: 16,
                  ),
              itemBuilder: (context, index) => MergeSemantics(
                    child: ListTile(
                      title: CommonText.medium(
                        state.listSettings[index].title,
                        size: 14,
                        color: AppColor.primaryDark,
                      ),
                      trailing: CupertinoSwitch(
                        value: state.listSettings[index].selected,
                        onChanged: (value) =>
                            BlocProvider.of<NotificationSettingsCubit>(context)
                                .onChangeSwitch(index, value),
                      ),
                      onTap: () {},
                    ),
                  ));
        },
      ),
    );
  }
}
