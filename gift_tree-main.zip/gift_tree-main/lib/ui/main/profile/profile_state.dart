part of 'profile_view.dart';


class ProfileState extends Equatable {



  @override
  List<Object?> get props => [];

  static ProfileState get initialState => ProfileState();

  ProfileState copyWith(
      ){
    return ProfileState();
  }
}
