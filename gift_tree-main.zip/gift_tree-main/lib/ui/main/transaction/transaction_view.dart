import 'dart:async';

import 'package:pessa_flow/extensions/extension.dart';
import 'package:pessa_flow/model/model.dart';
import 'package:pessa_flow/network/base_api_service.dart';
import 'package:pessa_flow/pref/app_pref.dart';
import 'package:pessa_flow/res/colors.dart';
import 'package:pessa_flow/res/images.dart';
import 'package:pessa_flow/ui/common_views/transaction_item_view.dart';
import 'package:pessa_flow/ui/main/main_view.dart';
import 'package:pessa_flow/utils/app_logger.dart';
import 'package:pessa_flow/utils/base_cubit.dart';
import 'package:equatable/equatable.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:pessa_flow/widgets/load_more_list.dart';
import 'package:pessa_flow/widgets/src/shimmer_item.dart';
import 'package:pessa_flow/widgets/widgets.dart';
import 'package:dart_extensions/dart_extensions.dart';

part 'transaction_cubit.dart';

part 'transaction_state.dart';

part 'transaction_service.dart';

class TransactionsView extends StatefulWidget {
  const TransactionsView({Key? key}) : super(key: key);

  @override
  _TransactionsViewState createState() => _TransactionsViewState();
}

class _TransactionsViewState extends State<TransactionsView> {
  @override
  Widget build(BuildContext context) {
    return BlocBuilder<TransactionCubit, TransactionState>(
      buildWhen: (previous, current) =>
          previous.listTransaction_ != current.listTransaction_,
      builder: (context, state) {
        return ShimmerList(
          itemCount: state.listTransaction_.length,
          physics: const BouncingScrollPhysics(
              parent: AlwaysScrollableScrollPhysics()),
          separatorBuilder: (context, index) => const Divider(indent: 84),
          itemBuilder: (context, index) =>
              TransactionItemView(state.listTransaction_[index]),
          shimmerBuilder: (context, index) => const ListItemShimmer(),
          onLoadMore: BlocProvider.of<TransactionCubit>(context).onLoadMore,
          onRefresh: BlocProvider.of<TransactionCubit>(context).onRefresh,
          isLoading: state.isLoading,
          reachAtEnd: state.reachAtEnd,
          padding: EdgeInsets.zero,
          emptyDataView: const EmptyDataView(
              image: AppImage.transfer, desc: "No Transactions Found"),
        );
      },
    );
  }
}
