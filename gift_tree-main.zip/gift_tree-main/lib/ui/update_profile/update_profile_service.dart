part of 'update_profile_view.dart';


class UpdateProfileService extends BaseApiService {
  UpdateProfileService(BuildContext context) : super(context);

  Future<dynamic> updateProfile(String fName, String lName , String phone , String email) async {
    return callApi(
      client.updateProfile(
        userId: AppPref.userId,
        fName: fName,
        lName: lName,
        email: email,
        phone: phone
      ),
    );
  }
  Future<User?> getProfile() async {
    try {
      return callApi(client.getProfile(AppPref.userId), doShowLoader: false);
    } catch (error) {
      AppLogger.log("MainService.getProfile -> $error");
    }
  }

}
