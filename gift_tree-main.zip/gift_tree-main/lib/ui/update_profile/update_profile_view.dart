import 'dart:async';

import 'package:pessa_flow/common/validator.dart';
import 'package:pessa_flow/constants/route.dart';
import 'package:pessa_flow/extensions/extension.dart';
import 'package:pessa_flow/generated/l10n.dart';
import 'package:pessa_flow/model/model.dart';
import 'package:pessa_flow/network/base_api_service.dart';
import 'package:pessa_flow/pref/app_pref.dart';
import 'package:pessa_flow/res/colors.dart';
import 'package:pessa_flow/res/images.dart';
import 'package:pessa_flow/ui/common_views/transaction_item_view.dart';
import 'package:pessa_flow/ui/main/main_view.dart';
import 'package:pessa_flow/utils/app_logger.dart';
import 'package:pessa_flow/utils/base_cubit.dart';
import 'package:pessa_flow/utils/input_formatters.dart';
import 'package:pessa_flow/widgets/common_app_bar.dart';
import 'package:pessa_flow/widgets/widgets.dart';
import 'package:equatable/equatable.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

part 'update_profile_cubit.dart';

part 'update_profile_state.dart';

part 'update_profile_service.dart';

class UpdateProfileView extends StatefulWidget {
  const UpdateProfileView({Key? key}) : super(key: key);

  @override
  _UpdateProfileViewState createState() => _UpdateProfileViewState();
}

class _UpdateProfileViewState extends State<UpdateProfileView> {
  @override
  Widget build(BuildContext context) {
    var initialState = BlocProvider.of<UpdateProfileCubit>(context).state;
    return Scaffold(
      appBar: CommonAppBarBlack(
        title: S.of(context).updateProfile,
        onBackTap: () => Navigator.of(context).pop(),
      ),
      body: Form(
        key: initialState.formKey,
        child: ListView(
          padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 12),
          children: [
            Container(
              padding: const EdgeInsets.fromLTRB(20, 8, 20, 8),
              child: CommonTextField(
                controller: initialState.nameController,
                labelText: S.of(context).firstName,
                hintText: S.of(context).enterYourName,
                keyboardType: TextInputType.name,
                focus: initialState.nameFocus,
                validator: (value) =>
                    value.isNullOrEmpty ? S.current.pleaseEnterYourName : null,
                inputFormatters: [UsernameInputFormatter()],
                fillColor: AppColor.white,
                textColor: AppColor.primary,
                cursorColor: AppColor.primary,
                borderColor: AppColor.greyLight,
              ),
            ),
            const SizeBoxH(8),
            Container(
              padding: const EdgeInsets.fromLTRB(20, 8, 20, 8),
              child: CommonTextField(
                controller: initialState.lastNameController,
                labelText: S.of(context).lastName,
                hintText: S.of(context).enterYourLastName,
                keyboardType: TextInputType.name,
                focus: initialState.lastNameFocus,
                validator: (value) =>
                    value.isNullOrEmpty ? S.current.pleaseEnterYourName : null,
                inputFormatters: [UsernameInputFormatter()],
                fillColor: AppColor.white,
                textColor: AppColor.primary,
                cursorColor: AppColor.primary,
                borderColor: AppColor.greyLight,
              ),
            ),
            const SizeBoxH(8),
            Container(
              padding: const EdgeInsets.fromLTRB(20, 8, 20, 8),
              child: CommonTextField(
                controller: initialState.phoneController,
                labelText: S.of(context).phoneNumber,
                hintText: S.of(context).enterYourPhoneNumber,
                keyboardType: TextInputType.phone,
                focus: initialState.phoneFocus,
                validator: validateMobileNumber,
                inputFormatters: [NumberInputFormatter(length: 10)],
                fillColor: AppColor.white,
                textColor: AppColor.primary,
                cursorColor: AppColor.primary,
                borderColor: AppColor.greyLight,
              ),
            ),
            const SizeBoxH(8),
            Container(
              padding: const EdgeInsets.fromLTRB(20, 8, 20, 8),
              child: CommonTextField(
                controller: initialState.emailController,
                labelText: S.of(context).email,
                hintText: S.of(context).enterEmailAddress,
                keyboardType: TextInputType.emailAddress,
                focus: initialState.emailFocus,
                validator: validateEmail,
                fillColor: AppColor.white,
                textColor: AppColor.primary,
                cursorColor: AppColor.primary,
                borderColor: AppColor.greyLight,
              ),
            ),
            const SizeBoxH(8),
            Container(
              padding: const EdgeInsets.fromLTRB(20, 8, 20, 8),
              child: CommonButton(
                onPressed:
                    BlocProvider.of<UpdateProfileCubit>(context).onSubmitTap,
                label: S.of(context).send,
                bgColor: AppColor.commonButton,
              ),
            ),
            const SizeBoxH(8),
          ],
        ),
      ),
    );
  }
}
