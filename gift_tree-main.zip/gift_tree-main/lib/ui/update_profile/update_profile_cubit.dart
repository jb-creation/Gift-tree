part of 'update_profile_view.dart';

class UpdateProfileCubit extends BaseCubit<UpdateProfileState> {
  final UpdateProfileService _service;

  UpdateProfileCubit(BuildContext context)
      : _service = UpdateProfileService(context),
        super(context, UpdateProfileState.initialState);

  Future<void> onSubmitTap() async {
    if (state.formKey.currentState!.validate()) {
      var result = await _service.updateProfile(
          state.nameController.text, state.lastNameController.text, state.phoneController.text, state.emailController.text);

      /*User? user = await _service.getProfile();
      if (user != null) {
        AppPref.user = user;
      }*/
      Navigator.of(context).pop();
    }
  }
}
