part of 'update_profile_view.dart';

class UpdateProfileState extends Equatable {
  final TextEditingController nameController;
  final TextEditingController lastNameController;
  final TextEditingController phoneController;
  final TextEditingController emailController;

  final FocusNode nameFocus;
  final FocusNode lastNameFocus;
  final FocusNode phoneFocus;
  final FocusNode emailFocus;

  final bool isNameFocused;
  final bool isLastNameFocused;
  final bool isPhoneFocused;
  final bool isEmailFocused;
  final GlobalKey<FormState> formKey;

  const UpdateProfileState(
      this.formKey,
      this.nameController,
      this.lastNameController,
      this.phoneController,
      this.emailController,
      this.nameFocus,
      this.lastNameFocus,
      this.phoneFocus,
      this.emailFocus,
      {this.isNameFocused = false,
      this.isLastNameFocused = false,
      this.isPhoneFocused = false,
      this.isEmailFocused = false});

  static UpdateProfileState get initialState => UpdateProfileState(
        GlobalKey<FormState>(),
        TextEditingController(text: AppPref.user?.FirstName),
        TextEditingController(text: AppPref.user?.LastName),
        TextEditingController(text: AppPref.user?.PhoneNumber),
        TextEditingController(text: AppPref.user?.Email),
        FocusNode(),
        FocusNode(),
        FocusNode(),
        FocusNode(),
      );

  @override
  List<Object?> get props => [];

  UpdateProfileState copyWith(
    bool? isNameFocused,
    bool? isLastNameFocused,
    bool? isPhoneFocused,
    bool? isEmailFocused,
  ) {
    return UpdateProfileState(
      formKey,
      nameController,
      lastNameController,
      phoneController,
      emailController,
      nameFocus,
      lastNameFocus,
      phoneFocus,
      emailFocus,
      isNameFocused: isNameFocused ?? this.isNameFocused,
      isLastNameFocused: isLastNameFocused ?? this.isLastNameFocused,
      isPhoneFocused: isPhoneFocused ?? this.isPhoneFocused,
      isEmailFocused: isEmailFocused ?? this.isEmailFocused,
    );
  }
}
