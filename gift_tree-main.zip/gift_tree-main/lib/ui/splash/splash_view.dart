import 'dart:async';

import 'package:pessa_flow/constants/route.dart';
import 'package:pessa_flow/pref/app_pref.dart';
import 'package:pessa_flow/res/colors.dart';
import 'package:pessa_flow/res/images.dart';
import 'package:pessa_flow/widgets/widgets.dart';
import 'package:flutter/material.dart';

class SplashView extends StatefulWidget {
  const SplashView({Key? key}) : super(key: key);

  @override
  _SplashViewState createState() => _SplashViewState();
}

class _SplashViewState extends State<SplashView> {
  late final Timer _timer;

  @override
  void initState() {
    WidgetsBinding.instance?.addPostFrameCallback((timeStamp) {
      _timer = Timer(const Duration(seconds: 3), navigateToNextScreen);
    });
    super.initState();
  }

  /// Handles navigation form this screen
  Future<void> navigateToNextScreen() async {
    _timer.cancel();
    Navigator.of(context).pushReplacementNamed(AppPref.isLogin ? AppRoute.mainScreen : AppRoute.welcomeScreen);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(gradient: AppColor.splashGradient),
        child: Stack(
          fit: StackFit.expand,
          children: [
            Image.asset(AppImage.bgSplash, fit: BoxFit.cover),
            const Center(
              child: SquareImageFromAsset(
                AppImage.logoSplash,
                size: 200,
                fit: BoxFit.contain,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
