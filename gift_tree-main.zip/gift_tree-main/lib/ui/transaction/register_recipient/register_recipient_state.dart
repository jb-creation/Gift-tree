part of 'register_recipient_view.dart';

class RegisterRecipientState extends Equatable {
  final TextEditingController nameController;
  final TextEditingController lastNameController;
  final TextEditingController phoneController;

  final FocusNode nameFocus;
  final FocusNode lastNameFocus;
  final FocusNode phoneFocus;

  final bool isNameFocused;
  final bool isLastNameFocused;
  final bool isPhoneFocused;

  final GlobalKey<FormState> formKey;

  const RegisterRecipientState(
    this.formKey,
    this.nameController,
    this.lastNameController,
    this.phoneController,
    this.nameFocus,
    this.lastNameFocus,
    this.phoneFocus, {
    this.isNameFocused = false,
    this.isLastNameFocused = false,
    this.isPhoneFocused = false,
  });

  static RegisterRecipientState getRegisterState(Contacts data) {
    return RegisterRecipientState(
      GlobalKey<FormState>(),
      TextEditingController(text: data.name),
      TextEditingController(text: ""),
      TextEditingController(text: data.number),
      FocusNode(),
      FocusNode(),
      FocusNode(),
    );
  }

  static RegisterRecipientState get initialState => RegisterRecipientState(
        GlobalKey<FormState>(),
        TextEditingController(text: AppPref.user?.FirstName),
        TextEditingController(text: AppPref.user?.LastName),
        TextEditingController(text: AppPref.user?.PhoneNumber),
        FocusNode(),
        FocusNode(),
        FocusNode(),
      );

  @override
  List<Object?> get props => [];

  RegisterRecipientState copyWith(
    bool? isNameFocused,
    bool? isLastNameFocused,
    bool? isPhoneFocused,
    bool? isEmailFocused,
  ) {
    return RegisterRecipientState(
      formKey,
      nameController,
      lastNameController,
      phoneController,
      nameFocus,
      lastNameFocus,
      phoneFocus,
      isNameFocused: isNameFocused ?? this.isNameFocused,
      isLastNameFocused: isLastNameFocused ?? this.isLastNameFocused,
      isPhoneFocused: isPhoneFocused ?? this.isPhoneFocused,
    );
  }
}
