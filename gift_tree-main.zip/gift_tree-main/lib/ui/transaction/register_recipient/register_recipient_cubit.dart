part of 'register_recipient_view.dart';

class RegisterRecipientCubit extends BaseCubit<RegisterRecipientState> {
  final Map<String, dynamic> args;
  final RegisterRecipientService _service;

  RegisterRecipientCubit(BuildContext context, this.args)
      : _service = RegisterRecipientService(context),
        super(
            context,
            (args["contact"] != null)
                ? RegisterRecipientState.getRegisterState(args["contact"])
                : RegisterRecipientState.initialState);

  Future<void> onSubmitTap() async {
    if (state.formKey.currentState!.validate()) {
      var result = await _service.registerRecipient(state.nameController.text,
          state.lastNameController.text, state.phoneController.text);

      /*User? user = await _service.getProfile();
      if (user != null) {
        AppPref.user = user;
      }*/
      Contacts contacts = args["contact"];
      contacts.RecipientID = result["RecipientID"];
      Navigator.of(context).pop(contacts);
    }
  }
}
