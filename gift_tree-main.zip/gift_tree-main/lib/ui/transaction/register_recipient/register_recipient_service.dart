part of 'register_recipient_view.dart';


class RegisterRecipientService extends BaseApiService {
  RegisterRecipientService(BuildContext context) : super(context);

  Future<dynamic> registerRecipient(String fName, String lName , String phone) async {
    return callApi(
      client.registerRecipient(
        userId: AppPref.userId,
        fName: fName,
        lName: lName,
        phone: phone
      ),
    );
  }
 /* Future<User?> getProfile() async {
    try {
      return callApi(client.getProfile(AppPref.userId), doShowLoader: false);
    } catch (error) {
      AppLogger.log("MainService.getProfile -> $error");
    }
  }*/

}
