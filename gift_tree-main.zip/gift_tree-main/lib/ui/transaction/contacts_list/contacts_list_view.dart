import 'dart:async';
import 'dart:typed_data';

import 'package:dart_extensions/src/iterable.dart';
import 'package:flutter_contacts/flutter_contacts.dart';
import 'package:pessa_flow/constants/route.dart';
import 'package:pessa_flow/extensions/extension.dart';
import 'package:pessa_flow/generated/l10n.dart';
import 'package:pessa_flow/model/model.dart';
import 'package:pessa_flow/network/base_api_service.dart';
import 'package:pessa_flow/pref/app_pref.dart';
import 'package:pessa_flow/res/colors.dart';
import 'package:pessa_flow/res/images.dart';
import 'package:pessa_flow/utils/app_logger.dart';
import 'package:pessa_flow/utils/base_cubit.dart';
import 'package:pessa_flow/utils/permission_utils/contacts_permission_utils.dart';
import 'package:pessa_flow/widgets/clickable_container.dart';
import 'package:pessa_flow/widgets/common_app_bar.dart';
import 'package:pessa_flow/widgets/load_more_list.dart';
import 'package:pessa_flow/widgets/src/shimmer_item.dart';
import 'package:pessa_flow/widgets/widgets.dart';
import 'package:equatable/equatable.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

part 'contacts_list_cubit.dart';

part 'contacts_list_state.dart';

part 'contact_service.dart';

class ContactsListView extends StatelessWidget {
  const ContactsListView({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    var initialState = BlocProvider.of<ContactsListCubit>(context).state;
    return Scaffold(
      appBar: CommonAppBarClose(
          title: BlocProvider.of<ContactsListCubit>(context).title,
          onBackTap: () => Navigator.of(context).pop()),
      body: NestedScrollView(
        floatHeaderSlivers: true,
        headerSliverBuilder: (context, innerBoxIsScrolled) => [
          SliverToBoxAdapter(
            child: Padding(
              padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 20),
              child: Theme(
                data: context.theme.copyWith(
                  inputDecorationTheme:
                      context.theme.inputDecorationTheme.copyWith(
                    fillColor: AppColor.greyMedium,
                    border: InputBorder.none,
                    enabledBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12),
                      borderSide: BorderSide.none,
                    ),
                  ),
                ),
                child: CommonTextField(
                  controller: initialState.searchController,
                  hintText: S.of(context).searchContactHint,
                  inputAction: TextInputAction.search,
                  keyboardType: TextInputType.name,
                  fillColor: AppColor.greyFill,
                  textColor: AppColor.primary,
                  cursorColor: AppColor.primary,
                  borderColor: AppColor.greyLight,
                  fieldSubmitted: (value) =>
                      BlocProvider.of<ContactsListCubit>(context)
                          .onSearched(value),
                  prefixIcon: IconButton(
                    onPressed: () {},
                    icon: const SquareSvgImageFromAsset(AppImage.searchIcon),
                  ),
                ),
              ),
            ),
          ),
          SliverPersistentHeader(
            delegate: _ContactsHeaderDelegate(),
            pinned: true,
            floating: true,
          ),
        ],
        body: BlocBuilder<ContactsListCubit, ContactsListState>(
          builder: (context, state) {
            return ShimmerList(
              onLoadMore: () async {},
              reachAtEnd: true,
              shimmerBuilder: (context, index) => const ListItemShimmer(),
              separatorBuilder: (context, index) => const Divider(
                indent: 16,
                endIndent: 16,
              ),
              isLoading: state.isLoading,
              itemCount: state.listContactsDisplay.length,
              itemBuilder: (context, index) {
                var contact = state.listContactsDisplay[index];
                return ClickableContainer(
                  highlightColor: AppColor.primary.withOpacity(0.05),
                  splashColor: AppColor.primary.withOpacity(0.1),
                  onTap: () => BlocProvider.of<ContactsListCubit>(context)
                      .onContactSelected(index),
                  padding:
                      const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
                  child: Row(
                    children: [
                      contact.image.isEmpty
                          ? const Icon(
                              Icons.account_circle_outlined,
                              color: AppColor.primary,
                              size: 48,
                            )
                          : ClipRRect(
                              borderRadius: BorderRadius.circular(16),
                              child: Image.memory(contact.image),
                            ),
                      const SizeBoxV(12),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            CommonText.medium(
                              contact.name,
                              size: 16,
                              color: AppColor.primary,
                            ),
                            const SizeBoxH(),
                            CommonText.medium(contact.number,
                                size: 14, color: AppColor.textPrimaryLight),
                          ],
                        ),
                      ),
                    ],
                  ),
                );
              },
              emptyDataView: const EmptyDataView(
                  image: AppImage.logoSplash, desc: "No Contacts Found"),
            );
          },
        ),
      ),
    );
  }
}

class _ContactsHeaderDelegate extends SliverPersistentHeaderDelegate {
  @override
  Widget build(
      BuildContext context, double shrinkOffset, bool overlapsContent) {
    return Container(
      color: AppColor.scaffoldBackground,
      padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 20),
      alignment: AlignmentDirectional.centerStart,
      child: CommonText.bold(
        S.of(context).allContacts,
        size: 18,
        color: AppColor.primary,
      ),
    );
  }

  @override
  double get maxExtent => 56;

  @override
  double get minExtent => 56;

  @override
  bool shouldRebuild(covariant SliverPersistentHeaderDelegate oldDelegate) =>
      true;
}
