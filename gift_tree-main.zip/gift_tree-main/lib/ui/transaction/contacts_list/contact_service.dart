part of 'contacts_list_view.dart';


class ContactService extends BaseApiService {
  ContactService(BuildContext context) : super(context);

  Future<dynamic> updateProfile(String fName, String lName , String phone , String email) async {
    return callApi(
      client.updateProfile(
        userId: AppPref.userId,
        fName: fName,
        lName: lName,
        email: email,
        phone: phone
      ),
    );
  }
  Future<dynamic> checkVerifiedCustomer(String number) async {
    try {
      return callApi(client.checkVerifiedCustomer(userId :AppPref.userId , number: number), doShowLoader: false);
    } catch (error) {
      AppLogger.log("MainService.getProfile -> $error");
    }
  }

}
