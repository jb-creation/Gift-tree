part of 'contacts_list_view.dart';

class ContactsListState extends Equatable {
  final TextEditingController searchController;
  final List<Contacts> listContacts;
  final List<Contacts> listContactsDisplay;
  final bool isLoading;
  final bool reachAtEnd;


  const ContactsListState(this.searchController,
      {this.listContacts = const [], this.listContactsDisplay = const [], this.reachAtEnd = false,
        this.isLoading = true,});

  @override
  List<Object?> get props => [listContacts , listContactsDisplay , isLoading, reachAtEnd];

  static ContactsListState get initialState =>
      ContactsListState(TextEditingController());

  ContactsListState copyWith({List<Contacts>? listContacts , List<Contacts>? list,     bool? isLoading,
    bool? reachAtEnd,}) {
    return ContactsListState(
      searchController,
      listContacts: listContacts ?? this.listContacts,
      listContactsDisplay: list ?? listContactsDisplay,
      isLoading: isLoading ?? this.isLoading,
      reachAtEnd: reachAtEnd ?? this.reachAtEnd,
    );
  }
}
