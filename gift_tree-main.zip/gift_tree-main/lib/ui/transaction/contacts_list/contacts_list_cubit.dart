part of 'contacts_list_view.dart';

class ContactsListCubit extends BaseCubit<ContactsListState> {
  final Map<String, dynamic> args;
  final ContactService _service;

  ContactsListCubit(BuildContext context, this.args)
      : _service = ContactService(context),
        super(context, ContactsListState.initialState) {
    Timer.run(() => _fetchContacts());
  }

  Future _fetchContacts() async {
    if (await ContactsPermissionUtils(context).checkPermission()) {
      var listContact = await FlutterContacts.getContacts(withProperties: true);
      List<Contact> listPhoneNumber = [];

      listPhoneNumber.addAll(listContact.filter((element) => element.phones
          .filter((e) =>
              e.number.startsWith("+255") ||
              e.number.startsWith("+254") ||
              // e.number.startsWith("+234") ||
              e.number.startsWith("+256") ||
              e.number.startsWith("+233"))
          .toList()
          .isNotEmpty));

      var contactList = listPhoneNumber.mapList((e) => Contacts(
          id: e.phones.length,
          name: e.name.first + " " + e.name.last,
          image: e.photo ?? Uint8List(0),
          number: e.phones.first.number.replaceAll(" ", "")));

      emit(state.copyWith(
          listContacts: contactList, list: contactList, isLoading: false));
    }
  }

  String get title {
    switch (args["type"]) {
      default:
        return "Contacts";
    }
  }

  void onContactSelected(int index) async {
    dynamic result =
        await _service.checkVerifiedCustomer(state.listContactsDisplay[index].number);
    print("CONTACT $result");
    if (result["RecipientID"] == null) {
      var result = await Navigator.of(context).pushNamed(
          AppRoute.registerRecipient,
          arguments: {"contact": state.listContactsDisplay[index]});

      if (result != null) {
        Navigator.of(context).pop(result);
      }
    } else {
      Contacts contacts = state.listContactsDisplay[index];
      contacts.RecipientID = result["RecipientID"];
      Navigator.of(context).pop(contacts);
    }

    // Navigator.of(context).pop();
  }

  void onSearched(String value) async {
    if (value.isNotEmpty) {
      emit(state.copyWith(
          list: state.listContacts
              .filter((element) => element.name.toLowerCase().contains(value.toLowerCase()))));
    } else {
      emit(state.copyWith(list: state.listContacts));
    }

    // Navigator.of(context).pop();
  }
}
