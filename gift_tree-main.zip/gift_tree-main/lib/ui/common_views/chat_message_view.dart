import 'package:pessa_flow/model/model.dart';
import 'package:flutter/material.dart';

class ChatMessageView extends StatelessWidget {
  final ChatMessage chatMessage;

  const ChatMessageView(this.chatMessage, {Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container();
  }
}
