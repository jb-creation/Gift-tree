const kCheckAnimationLottie = "assets/lottie/check_animation.json";
const kCheckAnimationWhiteLottie = "assets/lottie/check_animation_white.json";
const kParticleAnimationLottie = "assets/lottie/particles_animation.json";
const kCardWaveAnimationLottie = "assets/lottie/card_wave.json";