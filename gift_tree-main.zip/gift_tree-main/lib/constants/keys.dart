const String kServerEncryptionKey = "";
const String kServerEncryptionIV = "";

const String kMobileEncryptionKey = "";
const String kMobileEncryptionIV = "";
