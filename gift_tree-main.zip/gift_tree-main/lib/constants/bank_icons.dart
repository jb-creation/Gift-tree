const iciciLogo = "https://www.searchpng.com/wp-content/uploads/2019/01/ICICI-Bank-PNG-Icon-715x715.png";
const kotakLogo = "https://www.searchpng.com/wp-content/uploads/2019/11/Kotak-Mahindra-Bank-icon-715x715.jpg";
const axisLogo = "https://www.searchpng.com/wp-content/uploads/2019/01/Axis-Bank-PNG-Icon-715x715.png";
const sbiLogo = "https://www.searchpng.com/wp-content/uploads/2019/01/SBI-Bank-PNG-Icon-715x715.png";