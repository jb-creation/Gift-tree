
class ApiRepository {
  ApiRepository._();
}
