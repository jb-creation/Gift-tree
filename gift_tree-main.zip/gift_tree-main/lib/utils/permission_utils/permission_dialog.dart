import 'dart:ui';

import 'package:pessa_flow/constants/size.dart';
import 'package:pessa_flow/extensions/extension.dart';
import 'package:pessa_flow/generated/l10n.dart';
import 'package:pessa_flow/res/colors.dart';
import 'package:pessa_flow/widgets/widgets.dart';
import 'package:animations/animations.dart';
import 'package:flutter/material.dart';

class PermissionDialog extends StatelessWidget {
  final String description;
  final IconData icon;

  static Future<bool> show({
    required BuildContext context,
    required String description,
    required IconData icon,
  }) {
    return showModal(
      context: context,
      filter: ImageFilter.blur(sigmaX: 4, sigmaY: 4),
      builder: (context) =>
          PermissionDialog(icon: icon, description: description),
    ).then((value) => value ?? false);
  }

  const PermissionDialog(
      {Key? key, required this.description, required this.icon})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Dialog(
      elevation: 8,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      clipBehavior: Clip.hardEdge,
      child: Container(
        constraints: kDialogConstraints,
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Material(
              color: context.theme.colorScheme.primary,
              child: Container(
                width: double.infinity,
                padding:
                    const EdgeInsets.symmetric(vertical: 32, horizontal: 40),
                child: Icon(icon,
                    size: 48, color: context.theme.colorScheme.onPrimary),
              ),
            ),
            Padding(
              padding: const EdgeInsets.symmetric(vertical: 40, horizontal: 24),
              child: CommonText.medium(
                description,
                size: 14,
                color: AppColor.textPrimary,
              ),
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 8, 16, 8),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.end,
                children: [
                  TextButton(
                    onPressed: () => Navigator.of(context).pop(false),
                    child: CommonText.bold(S.of(context).notNow,
                        color: AppColor.textPrimaryLight, size: 14),
                  ),
                  TextButton(
                    onPressed: () => Navigator.of(context).pop(true),
                    child: CommonText.bold(S.of(context).continue_,
                        color: context.theme.colorScheme.primary, size: 14),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
