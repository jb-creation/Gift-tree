import 'dart:io';

import 'package:pessa_flow/utils/permission_utils/permission_dialog.dart';
import 'package:pessa_flow/utils/permissions/permission_handler.dart';

import 'package:flutter/material.dart';

abstract class PermissionUtils {
  final Permission permission;
  final BuildContext context;
  final IconData icon;
  final String description;

  PermissionUtils(this.context, this.permission, this.icon, this.description);

  Future<bool> get hasPermission => permission.isGranted;

  Future<bool> requestPermission() async {
    var isContinue = await PermissionDialog.show(
      context: context,
      description: description,
      icon: icon,
    );
    if (isContinue == true) {
      var result = await permission.request();
      if (result == PermissionStatus.granted || result == PermissionStatus.limited) {
        return true;
      } else if (result == PermissionStatus.permanentlyDenied) {
        onPermissionDenied();
      }
    }
    return false;
  }

  Future<bool> checkPermission() async {
    var status = await permission.status;
    if (status == PermissionStatus.granted || (Platform.isIOS && status == PermissionStatus.limited)) {
      return true;
    } else if (status == PermissionStatus.permanentlyDenied || status == PermissionStatus.neverAskAgain) {
      onPermissionDenied();
      return false;
    } else {
      return requestPermission();
    }
  }

  VoidCallback get onPermissionDenied;
}
