import 'dart:io';
import 'dart:ui';

import 'package:pessa_flow/generated/l10n.dart';
import 'package:pessa_flow/utils/permission_utils/storage_permission_utils.dart';
import 'package:pessa_flow/utils/permissions/permission_handler.dart';
import 'package:pessa_flow/widgets/common_dialog.dart';
import 'package:flutter/material.dart';

import 'permission_utils.dart';

class PhotosPermissionUtils extends PermissionUtils {
  PhotosPermissionUtils(BuildContext context)
      : super(context, Permission.photos, Icons.photo_library, S.current.photosPermissionDesc);

  @override
  Future<bool> checkPermission() {
    if (Platform.isAndroid) {
      return StoragePermissionUtils(context).checkPermission();
    }
    return super.checkPermission();
  }

  @override
  VoidCallback get onPermissionDenied => () {
        CommonDialog.show(
          title: S.current.permissionDenied,
          description: S.current.permissionDeniedDesc(S.current.photos),
          positiveButtonText: S.current.goToSettings,
          positiveButtonTap: () {
            Navigator.of(context).pop();
            openAppSettings();
          },
          negativeButtonText: S.current.cancel,
        );
      };
}
