import 'dart:ui';

import 'package:pessa_flow/generated/l10n.dart';
import 'package:pessa_flow/utils/permissions/permission_handler.dart';
import 'package:pessa_flow/widgets/common_dialog.dart';
import 'package:flutter/material.dart';

import 'permission_utils.dart';

class CameraPermissionUtils extends PermissionUtils {
  CameraPermissionUtils(BuildContext context)
      : super(context, Permission.camera, Icons.camera_alt, S.current.cameraPermissionDesc);

  @override
  VoidCallback get onPermissionDenied => () {
        CommonDialog.show(
          title: S.current.permissionDenied,
          description: S.current.permissionDeniedDesc(S.current.camera),
          positiveButtonText: S.current.goToSettings,
          positiveButtonTap: () {
            Navigator.of(context).pop();
            openAppSettings();
          },
          negativeButtonText: S.current.cancel,
        );
      };
}
