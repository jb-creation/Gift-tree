import 'package:pessa_flow/extensions/extension.dart';
import 'package:pessa_flow/generated/l10n.dart';
import 'package:pessa_flow/widgets/common_dialog.dart';
import 'package:flutter/material.dart';

class CommonUtils {
  static void showErrorDialog(String message, [VoidCallback? onButtonTap]) {
    CommonDialog.show(
      title: S.of(App.context).oops,
      description: message.trim(),
      positiveButtonText: S.of(App.context).okay,
    );
  }

  static void showNoInternetDialog() {
    CommonDialog.show(
      title: S.of(App.context).noInternet,
      description: S.of(App.context).noInternetDesc,
      positiveButtonText: S.of(App.context).okay,
    );
  }
}
