import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

class BaseCubit<State extends Object> extends Cubit<State> {
  final BuildContext _context;

  BaseCubit(this._context, State initialState) : super(initialState);

  BuildContext get context => _context;
}
