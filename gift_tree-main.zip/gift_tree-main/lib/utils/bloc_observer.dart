import 'package:pessa_flow/utils/app_logger.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

class MyBlocObserver extends BlocObserver {
  @override
  void onChange(BlocBase bloc, Change change) {
    AppLogger.log("${bloc.runtimeType} => ${change.currentState}");
    super.onChange(bloc, change);
  }

  @override
  void onCreate(BlocBase bloc) {
    AppLogger.log("${bloc.runtimeType} created");
    super.onCreate(bloc);
  }

  @override
  void onClose(BlocBase bloc) {
    AppLogger.log("${bloc.runtimeType} closed");
    super.onClose(bloc);
  }
}
