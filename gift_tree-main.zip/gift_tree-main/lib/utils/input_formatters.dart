import 'package:pessa_flow/common/common.dart';
import 'package:flutter/services.dart';

class NumberInputFormatter extends TextInputFormatter {
  final int length;
  final bool allowFloating;

  NumberInputFormatter({this.length = 255, this.allowFloating = false});

  @override
  TextEditingValue formatEditUpdate(TextEditingValue oldValue, TextEditingValue newValue) {
    if (newValue.text.length > length) return oldValue;
    if (newValue.text.length > oldValue.text.length) {
      if (allowFloating) {
        return double.tryParse(newValue.text) != null ? newValue : oldValue;
      } else {
        return int.tryParse(newValue.text) != null ? newValue : oldValue;
      }
    } else {
      return newValue;
    }
  }
}

class CardMonthInputFormatter extends TextInputFormatter {
  @override
  TextEditingValue formatEditUpdate(TextEditingValue oldValue, TextEditingValue newValue) {
    var newText = newValue.text.replaceAll("/", '');
    if (newText.isNotEmpty && int.tryParse(newText) == null) {
      return oldValue;
    } else if (newValue.text.length > 7) {
      return oldValue;
    } else if (newValue.text.length < oldValue.text.length) {
      return newValue;
    } else if (newValue.text.length < 2) {
      return newValue;
    } else if (newValue.text.length == 2) {
      return int.parse(newValue.text) > 12 ? oldValue : newValue;
    }

    var string = getFormattedCardMonth(newText, false);
    return newValue.copyWith(text: string, selection: TextSelection.collapsed(offset: string.length));
  }
}

class CardNumberInputFormatter extends TextInputFormatter {
  @override
  TextEditingValue formatEditUpdate(TextEditingValue oldValue, TextEditingValue newValue) {
    var newText = newValue.text.replaceAll(" ", '').trim();
    if (newValue.text.length < oldValue.text.length) {
      var text = newValue.text.trim();
      return newValue.copyWith(text: text, selection: TextSelection.collapsed(offset: text.length));
    } else if (newText.isNotEmpty && int.tryParse(newValue.text.split(" ").last) == null) {
      return oldValue;
    } else if (newValue.text.length < 4) {
      return newValue;
    } else if (newText.length > 20) {
      return oldValue;
    }
    var string = getFormattedCardNumberText(newText, false);
    return newValue.copyWith(text: string, selection: TextSelection.collapsed(offset: string.length));
  }
}

class UsernameInputFormatter extends TextInputFormatter {
  final RegExp usernameRegExp = RegExp(kNamePattern);

  @override
  TextEditingValue formatEditUpdate(TextEditingValue oldValue, TextEditingValue newValue) {
    if (newValue.text.length < oldValue.text.length) {
      return newValue;
    } else if (newValue.text.length > 50) {
      return oldValue;
    } else if (usernameRegExp.hasMatch(newValue.text)) {
      return newValue;
    } else {
      return oldValue;
    }
  }
}
